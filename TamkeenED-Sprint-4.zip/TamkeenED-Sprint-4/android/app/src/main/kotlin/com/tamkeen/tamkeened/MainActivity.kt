package com.tamkeen.tamkeened

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
